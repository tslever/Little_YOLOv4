
#ifndef TEST_DETECTOR
#define TEST_DETECTOR


void test_detector(
    char* datacfg,
    char* cfg,
    char* weights,
    char* filename,
    float thresh);


#endif